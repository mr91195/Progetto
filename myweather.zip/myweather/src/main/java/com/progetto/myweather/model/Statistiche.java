package com.progetto.myweather.model;

import java.util.Vector;

public class Statistiche {
	public String calcolaStatistiche(Vector <MeteoCitta> citta) {
		
		String finale1 = evidenziaMax(citta);
		String finale2 = evidenziaMin(citta);
	    String finale3 = evidenziaVarianzaMax(citta);
	    String finale4 = evidenziaVarianzaMin(citta);
	    
	     return  finale1 + finale2 + finale3 + finale4;
	    
	}
	
	
	public String evidenziaMax (Vector <MeteoCitta> citta) {

		String name = null;
		double temp_max = citta.get(0).temp_max;
		
		for (int i = 0; i < citta.size(); i++) {
			if(citta.get(i).temp_max > temp_max) {
				temp_max = citta.get(i).temp_max;
				name = citta.get(i).name;
				
			}
		 }
		
	String tempmax = Double.toString(temp_max);
	return "nome città : " + name + " temperatura massima : " + tempmax;
}
	
	

	public String evidenziaMin(Vector <MeteoCitta> citta) {
		
		String name= null;
		double temp_min = citta.get(0).temp_min;
		
		for (int i = 0; i < citta.size(); i++) {
			if(citta.get(i).temp_min < temp_min) {
				temp_min = citta.get(i).temp_min;
				name = citta.get(i).name;
			}
		 }
		
		String tempmin = Double.toString(temp_min);
		return "nome città : " + name + " temperatura minima " + tempmin;
	}
		
		
	

	public String evidenziaVarianzaMax(Vector <MeteoCitta> citta) {
			
			String name=null;
			double varianza = citta.get(0).varianza;
			
			for (int i = 0; i < citta.size(); i++) {
				if(citta.get(i).varianza > varianza) {
					varianza = citta.get(i).varianza;
					name = citta.get(i).name;
				}
			 }
			
			String varMax = Double.toString(varianza);
			return "nome città : " + name + " varianza massima " + varMax;
			
		}
	
	
	   public String evidenziaVarianzaMin(Vector <MeteoCitta> citta) {
		
		String name=null;
		double varianza = citta.get(0).varianza;
		
		for (int i = 0; i < citta.size(); i++) {
			if(citta.get(i).varianza < varianza) {
				varianza = citta.get(i).varianza;
				name = citta.get(i).name;
			}
		 }
		
		String varMin = Double.toString(varianza);
		return "nome città : " + name + " varianza minima " + varMin;
		
	}

}
