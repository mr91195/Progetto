package com.progetto.myweather.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class MeteoCitta {

	String name;
	double temp;
	double temp_min;
	double temp_max;
	double varianza;
	
	public MeteoCitta(String name, double temp, double temp_min, double temp_max) {
		this.name=name;
		this.temp=temp;
		this.temp_min=temp_min;
		this.temp_max=temp_max;
		this.varianza = temp_max-temp_min;
	}
	
	public String toString() {
		return name+"\nTemperatura: "+temp+"\nTemperatura minima: "+temp_min+
				"\nTemperatura max: "+temp_max+"\nVarianza :"+varianza;
	}
}
