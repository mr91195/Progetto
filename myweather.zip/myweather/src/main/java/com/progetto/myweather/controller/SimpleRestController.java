package com.progetto.myweather.controller;

import com.progetto.myweather.model.MeteoCitta;
import com.progetto.myweather.service.Actual;
import com.progetto.myweather.service.Actual;
import com.progetto.myweather.service.RequestApi;
import com.progetto.myweather.service.CallApi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.Vector;
import java.io.IOException;

	/*
	 * Controller dell'applicazione, sono presenti i vari Path che puo richiamare l'utente
	 */

@RestController
public class SimpleRestController {
	
	
	@Autowired
	Actual chiamata ;
	
	
	/*
	 * Path : /home, mostra i Path che l'utente ha a disposizione
	 */
	
	@RequestMapping("/home")
	public String home() {
		return "";
	}
	
	/*
	 * Path : /attuale, mostra le temperature attuali, mediante il parametro 'Box' (Box pre impostati)
	 * puo scegliere tra i vari box delle città confinanti con Ancona
	 */

	@GetMapping("/attuale")
	public ResponseEntity<Object> meteoAttuale(@RequestParam(name="box",defaultValue="box1")String box) throws IllegalArgumentException {
		
		return new ResponseEntity<>(chiamata.meteoActual(box), HttpStatus.OK);
	}
	
	/*
	 * Path : /attuale/ , mostra le temperature attuali dove l'utente puo scegliere manualmente il box da selezionare
	 */
	
	@GetMapping ("/attuale/rectangle")
	public ResponseEntity<Object> meteoAttualeBox(@RequestParam(name="lon-left") double lon_left,
												@RequestParam(name="lat-bottom") double lat_bottom,
												@RequestParam(name="lon-right") double lon_right,
												@RequestParam(name="lat-top") double lat_top){
		return new ResponseEntity<>(chiamata.meteoActualBox(lon_left, lat_bottom, lon_right, lat_top), HttpStatus.OK);
	}
	
	//prova_pt.3
	
	@GetMapping ("/prova")
	public ResponseEntity<Object> meteoActualBox(@RequestParam(name="lon_left") double lon_left,
								@RequestParam(name="lat-bottom") double lat_bottom,
								@RequestParam(name="lon-right") double lon_right,
								@RequestParam(name="lat-top") double lat_top){
		CallApi ca = new CallApi();
		
		return ResponseEntity<Object>(ca.ApiCallRectangle(lon_left, lat_bottom, lon_right, lat_top), HttpStatus.OK);
	}
	/*
	 * Path: /statitica, mostra le statistiche della temperatura , mediante il parametro 'Period'
	 * puo scegliere su che intervallo di tempo calcolare le statistiche
	 */
	
	@GetMapping("/statistica/{Box}/{Periodo}")
	public String statistiche() {
		return "";
	}
}
