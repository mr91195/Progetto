package com.progetto.myweather.service;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Vector;
import org.json.simple.*;
import org.json.simple.parser.*;
import java.util.Vector;
import com.progetto.myweather.model.MeteoCitta;
import org.springframework.stereotype.Service;

@Service
public class Actual implements RequestApi{
	
	Vector<MeteoCitta> citta = new Vector<MeteoCitta>();
	CallApi ca= new CallApi();
	
	public Vector<MeteoCitta> meteoActual(String box){
		
		citta = ca.ApiCall(box);   
		return citta;
	}
	
	public Vector<MeteoCitta> meteoActualBox(double lon_left, double lat_bottom, double lon_right, double lat_top){
		CallApi ca=new CallApi();
		return ca.ApiCallRectangle(lon_left, lat_bottom, lon_right, lat_top);
	}
	
	
	public void meteoStatistiche() {
		
	}
}
