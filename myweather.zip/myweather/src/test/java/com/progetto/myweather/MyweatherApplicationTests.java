package com.progetto.myweather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyweatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
