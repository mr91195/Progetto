package com.progetto.myweather;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyweatherApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyweatherApplication.class, args);
	}

}
